#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <ipfs/client.h>
#include <sstream>
#include <cstdio>
#include <typeinfo>
#include <stdexcept>
#include <system_error>
#include <exception> 

using namespace std;

#define FILE_PERM	0664
#define ONE_MB		1000000

/****************************************************************************************
 *
 *
 */
short genFile(char *fileName, char *data)
{
	int fd = 0, w_byte = 0, offs = 0;
	
	// open/create the file
	fd = open(fileName,O_WRONLY | O_CREAT, FILE_PERM);
	if(fd < 0)
	{
		perror( "[SORRY] : ");
		return -1;
	}
	
	// create hole-in-file
	offs = lseek(fd,ONE_MB,SEEK_SET);
	if(offs < 0)
	{
		perror( "[SORRY] : ");
		close(fd);
		return -1;
	}
	
	// write into file
	w_byte = write(fd,data,strlen(data));
	if(w_byte < 0)
	{
		perror( "[SORRY] : ");
		close(fd);
		return -1;
	}
	
	// close the file
	close(fd);
	
	return 0;
}

/*****************************************************************************************
 * 
 *
 */
short uploadFile(char *fileName, char *hash)
{
	short status = 0;

	try 
	{
		// get the ipfs-client object, and connect the ipfs
		ipfs::Client cObj("localhost",5001);
	
		// create json object for getting the responce result
		ipfs::Json getRes;
	
		// call the method to add the file into ipfs
		cObj.FilesAdd({{fileName, ipfs::http::FileUpload::Type::kFileName,fileName}},&getRes);
	
		// get the hash from the JSON
		string FileHash = (getRes[0]["hash"]).dump(2);
	
		// vanish the previous buffer data
		memset(hash,0,sizeof(hash));
	
		// copy the hash
		memcpy(hash, FileHash.c_str(),FileHash.length());
	}
	catch(std::exception ex)
	{
		cout << "Exception : "<< ex.what() << endl;
		status = -1;
	}
	
	return status;
}

/*
NOTES : FilesAdd - Second parameter and third parameter

	1)	[ ipfs::http::FileUpload::Type::kFileName,fileName ] 	- for sending file itself
	2)	[ ipfs::http::FileUpload::Type::kFileContents, "abcd" ]	- for sending content with new file
**/

/*****************************************************************************************/
int main()
{
	int ret = 0;
	char fileName[10] = "myfile1";
	char buffer[50] = "HELLO";
	unsigned long fileCnt = 0;

	for(int index = 0; ; index++)
	{
		// create the file locally
		ret = genFile(fileName, buffer);
		if(ret == 0)
		{
			// upload the file on ipfs
			ret = uploadFile(fileName,buffer);
			if(ret < 0)
			{
				continue;
			}
	
			fileCnt++;
		
			// message
			cout << "[INFO_] : File uploaded : "  << buffer << " ["<< fileCnt <<"]" <<  endl;
		}
		else
		{
			cout << "[SORRY] : Something went wrong" << endl;
		}
	}
		
	return 0; 
}
